import 'package:pokemonapp/model/pokemon_model.dart';

class SearchModel {
  static List<Pokemon> searchedData = [];
}
